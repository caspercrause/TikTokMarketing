# TikTokMarketing

This is a package you can use to download reporting data from the TikTok Marketing API